package com.LibraryManagementGroup.LibraryManagement.repository;
import com.LibraryManagementGroup.LibraryManagement.entity.Author;
import com.LibraryManagementGroup.LibraryManagement.entity.Book;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.ArrayList;

public interface BookRepository extends JpaRepository<Book, Integer> {

    @Query(nativeQuery = true, value = "select * from author")
    ArrayList<Author> getAuthors(int page, int perPage);
}
