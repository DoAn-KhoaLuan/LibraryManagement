package com.LibraryManagementGroup.LibraryManagement.common.requests.authorrequests;

public class CreateAuthor {
    private String authorName;
}
