package com.LibraryManagementGroup.LibraryManagement.common.requests.categoryrequests;

public class CreateCategoryRequest {
    private String categoryName;
    private String description;
    private String note;
}
