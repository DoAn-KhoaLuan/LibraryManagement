package com.LibraryManagementGroup.LibraryManagement.common.requests.categoryrequests;

public class UpdateCategoryRequest {
    private String id;
    private String categoryName;
    private String description;
    private String note;
}
