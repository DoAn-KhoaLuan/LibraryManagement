package com.LibraryManagementGroup.LibraryManagement.common.requests.commons;

public class DeleteItemRequest {
    private Integer id;
}
