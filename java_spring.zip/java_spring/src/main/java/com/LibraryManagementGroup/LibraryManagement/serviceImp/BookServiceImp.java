package com.LibraryManagementGroup.LibraryManagement.serviceImp;

import com.LibraryManagementGroup.LibraryManagement.common.requests.commons.GetPageItemsRequest;
import com.LibraryManagementGroup.LibraryManagement.entity.Author;
import com.LibraryManagementGroup.LibraryManagement.repository.BookRepository;
import com.LibraryManagementGroup.LibraryManagement.service.IBookService;
import net.minidev.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class BookServiceImp implements IBookService {
    @Autowired
    BookRepository bookRepository;

    @Override
    public JSONObject getAuthors(GetPageItemsRequest req) {
        ArrayList<Author> entityAuthorArr = bookRepository.getAuthors(req.getPage(), req.getPerPage());
        ArrayList<JSONObject> objectAuthorArr = new ArrayList<>();
        for (Author author: entityAuthorArr) {
            System.out.println("entityAuthorArr");
            JSONObject obj = author.toObject();
            objectAuthorArr.add(obj);
        };
        JSONObject obj = new JSONObject();
        obj.put("test", 1221);
        return obj;
    }
}
